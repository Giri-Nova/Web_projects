import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

client = Groq(api_key=os.getenv("GROQ_API_KEY"))

def get_ai_response(user_message):
    completion = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {"role": "system", "content": "You are NOVA AI, a helpful assistant."},
            {"role": "user", "content": user_message}
        ]
    )
    return completion.choices[0].message.content
