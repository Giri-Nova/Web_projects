from rest_framework.decorators import api_view
from rest_framework.response import Response
from .db import chat_collection
from .ai_service import get_ai_response

@api_view(['POST'])
def chat_api(request):
    user_message = request.data.get("message")

    if not user_message:
        return Response({"error": "Message is required"}, status=400)

    ai_reply = get_ai_response(user_message)

    chat_collection.insert_one({
        "user_message": user_message,
        "ai_reply": ai_reply
    })

    return Response({
        "reply": ai_reply
    })
