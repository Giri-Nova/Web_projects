const chatBox = document.getElementById("chat-box");

function addMessage(text, className) {
  const msg = document.createElement("div");
  msg.className = className;
  msg.innerText = text;
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function handleEnter(e) {
  if (e.key === "Enter") sendMessage();
}

async function sendMessage() {
  const input = document.getElementById("userInput");
  const message = input.value.trim();
  if (!message) return;

  addMessage(message, "user-msg");
  input.value = "";

  const typing = document.createElement("div");
  typing.className = "bot-msg";
  typing.innerText = "NOVA is thinking...";
  chatBox.appendChild(typing);

  try {
    const response = await fetch("http://127.0.0.1:8000/api/chat/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });

    const data = await response.json();
    chatBox.removeChild(typing);
    addMessage(data.reply, "bot-msg");

  } catch {
    chatBox.removeChild(typing);
    addMessage("Unable to reach NOVA AI", "bot-msg");
  }
}
